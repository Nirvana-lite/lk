<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/forum/admin/points_edit.php");
?>