<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/search/admin/search_tags.php");
?>
