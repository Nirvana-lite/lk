<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/forum/admin/forum_dictionary.php");
?>