<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/iblock/admin/iblock_element_search.php");?>
