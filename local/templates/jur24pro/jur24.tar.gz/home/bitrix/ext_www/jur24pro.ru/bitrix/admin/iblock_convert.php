<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/iblock/admin/iblock_convert.php");?>
