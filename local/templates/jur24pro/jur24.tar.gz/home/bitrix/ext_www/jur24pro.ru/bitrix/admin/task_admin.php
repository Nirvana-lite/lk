<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/admin/task_admin.php");
?>