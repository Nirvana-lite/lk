<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/forum/admin/group_edit.php");
?>