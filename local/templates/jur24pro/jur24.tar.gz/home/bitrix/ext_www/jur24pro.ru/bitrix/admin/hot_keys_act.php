<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/interface/hot_keys_act.php");?>
