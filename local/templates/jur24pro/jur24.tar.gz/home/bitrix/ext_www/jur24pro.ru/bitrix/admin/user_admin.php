<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/admin/user_admin.php");
?>