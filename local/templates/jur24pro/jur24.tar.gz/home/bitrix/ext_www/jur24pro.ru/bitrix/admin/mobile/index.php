<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/mobileapp/admin/mobile/index.php");
?>