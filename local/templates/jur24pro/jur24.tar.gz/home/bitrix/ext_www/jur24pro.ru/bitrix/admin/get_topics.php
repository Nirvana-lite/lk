<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/forum/tools/get_topics.php");
?>