<?
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/mobileapp/admin/mobile_app_list.php");


