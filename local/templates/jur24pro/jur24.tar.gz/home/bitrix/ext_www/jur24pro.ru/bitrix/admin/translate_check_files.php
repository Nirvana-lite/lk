<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/translate/admin/translate_check_files.php");