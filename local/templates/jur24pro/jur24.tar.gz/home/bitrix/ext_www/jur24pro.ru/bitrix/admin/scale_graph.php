<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/scale/admin/graph.php");
?>