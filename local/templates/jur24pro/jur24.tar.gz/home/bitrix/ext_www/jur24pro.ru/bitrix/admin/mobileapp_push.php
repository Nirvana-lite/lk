<?
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/mobileapp/admin/mobileapp_push.php");


