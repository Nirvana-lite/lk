<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/micros.comment/admin/md_last_comment.php");
?>
