<?
$MESS ['NEWS_SHOW_COMPONENT_NAME'] = "Новости RSS";
$MESS ['NEWS_SHOW_COMPONENT_DESCRIPTION'] = "Выводит новостную ленту RSS";
$MESS ['INFORMERS'] = "Информеры";
$MESS ['TITLE_PM'] = "P.M. Group";
?>