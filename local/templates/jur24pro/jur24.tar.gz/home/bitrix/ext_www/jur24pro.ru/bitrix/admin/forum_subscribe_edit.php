<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/forum/admin/forum_subscribe_edit.php");
?>