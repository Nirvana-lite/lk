<?
$MESS ['IBLOCK_ELEMENT_ADD_FORM_NAME'] = "Форма добавления / редактирования";
$MESS ['IBLOCK_ELEMENT_ADD_FORM_DESCRIPTION'] = "Форма добавления / редактирования элемента инфоблока";
$MESS ['T_IBLOCK_DESC_ELEMENT_ADD'] = "Добавление элементов";
?>