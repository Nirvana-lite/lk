<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/admin/short_uri_admin.php");
?>
