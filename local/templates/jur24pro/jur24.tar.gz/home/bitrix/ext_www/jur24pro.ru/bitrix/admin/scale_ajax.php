<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/scale/admin/ajax.php");
?>