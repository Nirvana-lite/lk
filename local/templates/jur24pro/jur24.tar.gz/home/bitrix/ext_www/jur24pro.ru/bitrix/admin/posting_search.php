<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/subscribe/admin/posting_search.php");
?>
