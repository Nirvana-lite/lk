<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/interface/get_search.php");
?>