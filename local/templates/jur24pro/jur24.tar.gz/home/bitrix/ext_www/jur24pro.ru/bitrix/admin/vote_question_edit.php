<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/vote/admin/vote_question_edit.php");
?>