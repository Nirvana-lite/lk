<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/subscribe/admin/subscr_admin.php");
?>
