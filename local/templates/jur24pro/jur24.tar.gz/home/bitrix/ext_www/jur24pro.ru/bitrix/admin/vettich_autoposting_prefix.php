<?
$vettich_autoposting_prefix_dir = $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/vettich.autoposting';
if(!file_exists($vettich_autoposting_prefix_dir))
	$vettich_autoposting_prefix_dir = $_SERVER['DOCUMENT_ROOT'].'/local/modules/vettich.autoposting';
?>
