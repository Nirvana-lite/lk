<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/interface/desktop.php");
?>