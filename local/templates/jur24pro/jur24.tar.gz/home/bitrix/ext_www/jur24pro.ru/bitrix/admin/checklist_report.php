<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/admin/checklist_report.php");
?>
