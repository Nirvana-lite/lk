<? require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/header.php");
global $USER;
$include_js = false;
if ($USER->IsAdmin()) {

    /*
     * найти все элементы без раздела -> верхний уровень
    $arSelect = Array("ID", "IBLOCK_ID", "NAME", "DEPTH_LEVEL", "SECTION_ID" );//IBLOCK_ID и ID обязательно должны быть указаны, см. описание arSelectFields выше
    $arFilter = Array("IBLOCK_ID"=>IntVal(17), "DEPTH_LEVEL" => 0, "SECTION_ID" => 0);
    $ressert = CIBlockElement::GetList(Array(), $arFilter, false, false, $arSelect);

    while ($asdqwe = $ressert->GetNext()) {

        echo "id-".$asdqwe['ID']." name-".$asdqwe['NAME']."<hr>";
    }
    die('');*/


    $id = intval($_REQUEST['ID']);
    $id = preg_replace("/[^0-9]/", '', $id);

    if( !$id > 0 ) {die('Нет такого элемента'); exit();}

    $res = CIBlockElement::GetByID($id);
    if ($ar_res = $res->GetNext()) {
        $include_js = true;

        $ipropValues = new \Bitrix\Iblock\InheritedProperty\ElementValues(
            $ar_res["IBLOCK_ID"], // ID инфоблока
            $ar_res["ID"] // ID элемента
        );
        $arElMetaProp = $ipropValues->getValues();

        ?>
        <div class="wrap">
            <h1 class="h1_manag">Редактирование</h1>
            <form class="frm editform" ENCTYPE="multipart/form-data">
                <div class="massege"></div>
                <div class="form-group">
                    <label for="title-element">Title (заголовок который в коде)</label>
                    <input id="title-element" name="title" type="text" class="form-control"
                           placeholder="Title (заголовок который в коде)"
                           value="<?= $arElMetaProp['ELEMENT_META_TITLE']; ?>">
                </div>

                <div class="form-group">
                    <label for="name-element">Название статьи - в списке ( ссылка тоже меняется )</label>
                    <input id="name-element" name="name" type="text" class="form-control" placeholder="Название статьи"
                           value="<?= $ar_res['~NAME'] ?>">
                </div>

                <div class="form-group">
                    <label for="description-element">Анонс статьи и Description</label>
                    <textarea name="description" id="description-element" class="form-control" rows="5"
                              placeholder="Анонс статьи"><? echo strip_tags($ar_res['PREVIEW_TEXT']); ?></textarea>
                </div>
                <? if (!isset($_REQUEST['hiderazdel'])) {

                    $SectList = CIBlockSection::GetList(
                        array("NAME" => "ASC"),                       // сортировка
                        array("IBLOCK_ID" => $ar_res["IBLOCK_ID"], "ACTIVE" => "Y"),  // фильтр
                        false,                                    // количество элементов
                        array("ID", "IBLOCK_ID", "NAME"),        // выбираемые поля
                        false                                   // пагинация
                    );

                    //$selSects = $SectList->Fetch();

                    //if($selSects){
                       if (intval($SectList->SelectedRowsCount())>0){

                    ?>
                    <div class="form-group">
                        <label for="razdel-element">Разделы</label>
                        <select name="section_id" class="form-control">
                            <?

                            while ($SectListGet = $SectList->GetNext()) {
                                if ($SectListGet['ID'] == $ar_res['IBLOCK_SECTION_ID']) {
                                    $select_section = "selected='selected'";
                                } else {
                                    $select_section = "";
                                }
                                ?>
                                <option value="<?= $SectListGet['ID'] ?>" <?= $select_section; ?>><?= $SectListGet['NAME'] ?></option>
                            <? } ?>
                        </select>
                    </div>
                <? } else {?>
                        <input type="hidden" value="no" name="section_id">
                    <? } ?>
                <? } else { ?>
                    <input type="hidden" value="no" name="section_id">
                <? } ?>

                <div class="form-group">
                    <label for="photo-element">Фото статьи</label>
                    <?= CFile::ShowImage($ar_res['DETAIL_PICTURE'], 150, 150, "border='0' class='img_editman'", "", false); ?>
                    <? echo CFile::InputFile(
                        "photo",                // name
                        0,                     // size
                        $ar_res['DETAIL_PICTURE'],          // old picture
                        false,    // save picture
                        0,
                        "IMAGE",
                        'class="form-control" id="photo-element"',
                        0,
                        '',
                        '',
                        false,
                        false
                    ); ?>
                    <input type="hidden" value="<?= $ar_res['DETAIL_PICTURE']; ?>" name="deletepicture">
                    <span class="dop_text"><label for="photo_del">старой картинки</label></span>
                </div>

                <div class="form-group">
                    <label for="h1-element">h1 - видимый заголовок</label>
                    <input id="h1-element" name="h1" type="text" value="<?= $arElMetaProp['ELEMENT_PAGE_TITLE'] ?>"
                           class="form-control"
                           placeholder="h1">
                </div>

                <div class="form-group">
                    <label for="text-element">Текст статьи</label>

                    <?php
                    $APPLICATION->IncludeComponent(
                        "componentmanager:editor.tiny.mce",
                        "",
                        array(
                            "TEXT" => $ar_res["DETAIL_TEXT"],
                            "TEXTAREA_NAME" => "text",
                            "TEXTAREA_ID" => "text-element",
                            "TEXTAREA_WIDTH" => "99.9%",  //
                            "TEXTAREA_HEIGHT" => "300",    //
                            "INIT_ID" => "ID", //
                            "PATH_SAVE_PHOTO" => "/upload/tmp",
                            "TYPE_EDITOR" => "TYPE_1"
                        ),
                        false
                    );
                    ?>
                </div>

                <div class="form-group">
                    <label for="tags-element">Теги через запятую</label>
                    <input id="tags-element" name="tags" type="text" class="form-control"
                           value="<?= $ar_res["TAGS"]; ?>">
                </div>

                <div class="form-group">
                    <input type="hidden" value="editelement" name="namefnc">
                    <input type="hidden" value="<?= $ar_res["IBLOCK_ID"]; ?>" name="idblock">
                    <input type="hidden" value="<?= $ar_res['ID']; ?>" name="id">
                    <input type="submit" class="btn btn-success" value="Сохранить изменения">
                </div>
                <? $ipropValues->clearValues(); ?>
            </form>
        </div>
    <? } else {

        global $APPLICATION;
        $APPLICATION->RestartBuffer();
        $APPLICATION->AddChainItem("404");
        include $_SERVER['DOCUMENT_ROOT'] . '/404.php';
    }

} else {

    global $APPLICATION;
    $APPLICATION->RestartBuffer();
    $APPLICATION->AddChainItem("404");
    include $_SERVER['DOCUMENT_ROOT'] . '/404.php';

} ?>

<?
if ($include_js) { // если true то подключаем js-ajax для выполнения
    ?>


    <style>
        #photo_del {
            width: 16px;
            height: 16px;
        }

        span.dop_text {
            font-weight: bold;
            font-size: 100%;
        }

        img.img_editman {
            width: 200px !important;
            display: block;
            margin-top: 12px;
            margin-bottom: 12px;
            height: auto !important;
        }

        h1.h1_manag {
            margin-top: 15px;
            margin-bottom: 15px;
        }

        .massege {
            display: none;
            padding: 10px;
            margin-bottom: 15px;
        }

        .massege.error {
            display: block;
            color: red;
        }

        .massege.suc {
            display: block;
            color: green;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: inline-block;
            max-width: 100%;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-control {
            display: block;
            width: 100%;
            height: 34px;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.42857143;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            border-radius: 4px;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
            -webkit-transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;
            -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
            transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
        }

        .form-control:focus {
            border-color: #66afe9;
            outline: 0;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 8px rgba(102, 175, 233, .6);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075), 0 0 8px rgba(102, 175, 233, .6);
        }

        textarea.form-control {
            height: auto;
        }

        .btn {
            display: inline-block;
            padding: 6px 12px;
            margin-bottom: 0;
            font-size: 14px;
            font-weight: normal;
            line-height: 1.42857143;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
            cursor: pointer;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            background-image: none;
            border: 1px solid transparent;
            border-radius: 4px;
        }

        .btn-success {
            color: #fff;
            background-color: #5cb85c;
            border-color: #4cae4c;
        }

    </style>
    <script>
        $(function () {

            $('form.editform').off();
            $("form.editform").submit(function (e) {
                e.preventDefault();
                var form_data = new FormData(this);

                $.ajax({
                    url: '/local/ajax/ajax_manager/ajax_manager.php',
                    type: 'POST',
                    data: form_data,
                    contentType: false,
                    cache: false,
                    processData: false
                }).done(function (response) { //
                    var data = $.parseJSON(response);
                    if (data.ACTIVE == 'Y') {
                        $("form.editform .massege").addClass('suc');
                    } else {
                        $("form.editform .massege").addClass('error');
                    }
                    $("form.editform .massege").html(data.MASSEGE);

                    setTimeout(function () {
                        $("form.editform .massege").removeClass().addClass('massege');
                    }, 3000);

                });


            });

        });

    </script>

<? } ?>

<? require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/footer.php"); ?>
