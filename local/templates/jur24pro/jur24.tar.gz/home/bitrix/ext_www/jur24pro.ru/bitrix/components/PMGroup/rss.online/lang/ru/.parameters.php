<?
$MESS['SETTINGS_NEWS'] = 'Настройки новостной ленты';
$MESS['LINK_NEWS'] = 'Ссылка на RSS';
$MESS['NUMBER_NEWS'] = 'Количество выводимых новостей';
?>