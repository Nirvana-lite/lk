<?
define("MODULE_ID", "iblock");
define("ENTITY", "CIBlockDocument");
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/bizproc/admin/bizproc_selector.php");
?>