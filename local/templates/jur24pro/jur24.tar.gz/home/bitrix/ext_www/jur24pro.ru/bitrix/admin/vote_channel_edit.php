<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/vote/admin/vote_channel_edit.php");
?>