<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/imyie.popupadv/admin/banner_edit.php");?>
