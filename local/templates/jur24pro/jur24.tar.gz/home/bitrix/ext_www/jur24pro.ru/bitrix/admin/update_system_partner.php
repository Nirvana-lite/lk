<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/admin/update_system_partner.php");
?>