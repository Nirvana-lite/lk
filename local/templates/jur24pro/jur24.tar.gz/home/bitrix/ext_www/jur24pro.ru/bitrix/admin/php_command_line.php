<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/admin/php_command_line.php");
?>