<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/mobileapp/admin/mobile_designer.php");
?>
