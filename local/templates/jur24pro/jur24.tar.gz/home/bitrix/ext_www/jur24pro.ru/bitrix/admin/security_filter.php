<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/security/admin/security_filter.php");
?>
