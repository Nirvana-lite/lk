<?
$arTooltips = array(
	"arrCURRENCY_FROM" => GetMessage("arrCURRENCY_FROM_TIP"),
	"CURRENCY_BASE" => GetMessage("CURRENCY_BASE_TIP"),
	"RATE_DAY" => GetMessage("RATE_DAY_TIP"),
	"SHOW_CB" => GetMessage("SHOW_CB_TIP"),
	"CACHE_TYPE" => GetMessage("CACHE_TYPE_TIP"),
	"CACHE_TIME" => GetMessage("CACHE_TIME_TIP"),
);
?>