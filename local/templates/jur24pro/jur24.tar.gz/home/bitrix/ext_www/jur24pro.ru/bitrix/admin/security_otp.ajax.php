<?php
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/security/admin/security_otp.ajax.php");
