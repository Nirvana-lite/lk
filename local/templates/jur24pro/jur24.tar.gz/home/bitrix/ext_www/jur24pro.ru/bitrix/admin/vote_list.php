<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/vote/admin/vote_list.php");
?>