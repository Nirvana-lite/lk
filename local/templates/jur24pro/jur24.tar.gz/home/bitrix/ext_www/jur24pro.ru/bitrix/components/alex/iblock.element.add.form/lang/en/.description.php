<?
$MESS ['IBLOCK_ELEMENT_ADD_FORM_NAME'] = "Creation and editing form";
$MESS ['IBLOCK_ELEMENT_ADD_FORM_DESCRIPTION'] = "Information block element creation and editing form";
$MESS ['T_IBLOCK_DESC_ELEMENT_ADD'] = "Add elements";
?>
