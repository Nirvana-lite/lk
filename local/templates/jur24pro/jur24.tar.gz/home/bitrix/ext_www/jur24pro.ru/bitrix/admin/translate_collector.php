<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/translate/admin/translate_collector.php");