<?php
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/highloadblock/admin/highloadblock_export.php');