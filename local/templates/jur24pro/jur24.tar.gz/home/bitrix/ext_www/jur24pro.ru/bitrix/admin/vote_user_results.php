<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/vote/admin/vote_user_results.php");
?>