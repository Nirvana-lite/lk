<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/admin/type_admin.php");
?>