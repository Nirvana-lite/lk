<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/admin/event_log.php");
?>
