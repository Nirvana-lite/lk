<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/security/admin/security_otp_recovery_codes.php");
