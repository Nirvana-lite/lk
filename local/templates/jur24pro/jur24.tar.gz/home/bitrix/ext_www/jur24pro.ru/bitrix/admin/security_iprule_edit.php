<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/security/admin/security_iprule_edit.php");
?>
