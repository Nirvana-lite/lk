<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/public/get_start_menu.php");
?>