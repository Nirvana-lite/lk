<?
$MESS ['arrCURRENCY_FROM_TIP'] = "Select here currencies whose quotes are to be displayed in the table.";
$MESS ['CURRENCY_BASE_TIP'] = "Select here one of the defined currencies. Other currencies (selected above) will be indicated relative to this currency.";
$MESS ['RATE_DAY_TIP'] = "Specify the currency quote date. If there is no quote for this date, the default rate will be displayed.";
$MESS ['SHOW_CB_TIP'] = "If checked, rates will be indicated relative to RUR using the Bank of Russia information. Effective if only the <b>Currency to convert to</b> field is set to RUR.";
$MESS ['CACHE_TYPE_TIP'] = "<i>Auto</i>: the cache is valid during the time predefined in the cache settings;<br /><i>Cache</i>: always cache for the period specified in the next field;<br /><i>Do not cahce</i>: no caching is performed.";
$MESS ['CACHE_TIME_TIP'] = "Specify here the period of time during which the cache is valid.";
?>
