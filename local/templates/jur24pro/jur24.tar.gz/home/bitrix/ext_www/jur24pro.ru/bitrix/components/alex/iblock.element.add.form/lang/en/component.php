<?
$MESS["IBLOCK_ADD_ERROR_REQUIRED"] = "The field '#PROPERTY_NAME#' is required!";
$MESS["IBLOCK_ADD_ELEMENT_NOT_FOUND"] = "Element was not found";
$MESS["IBLOCK_ADD_ACCESS_DENIED"] = "Access denied";
$MESS["IBLOCK_FORM_WRONG_CAPTCHA"] = "The symbols you typed are incorrect";
$MESS["IBLOCK_ADD_MAX_ENTRIES_EXCEEDED"] = "Record limit exceeded";
$MESS["IBLOCK_ADD_MAX_LEVELS_EXCEEDED"] = "Section limit of #MAX_LEVELS# exceeded";
$MESS["IBLOCK_ADD_LEVEL_LAST_ERROR"] = "Can add to only sections of the last level";
$MESS["IBLOCK_USER_MESSAGE_ADD_DEFAULT"] = "New element has been successfully created";
$MESS["IBLOCK_USER_MESSAGE_EDIT_DEFAULT"] = "Changes has been saved successfully";
$MESS["IBLOCK_ERROR_FILE_TOO_LARGE"] = "The uploaded file is too large";
$MESS["CC_BIEAF_ACCESS_DENIED_STATUS"] = "You do not have enough permissions to edit this record in its current state";
$MESS["CC_BIEAF_IBLOCK_MODULE_NOT_INSTALLED"] = "Information blocks module is not installed";
?>