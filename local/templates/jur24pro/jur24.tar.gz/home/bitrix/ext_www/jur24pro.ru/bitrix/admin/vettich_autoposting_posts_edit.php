<?
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/admin/vettich_autoposting_prefix.php');
require($vettich_autoposting_prefix_dir."/admin/vettich_autoposting_posts_edit.php");
?>