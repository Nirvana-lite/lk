<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/perfmon/admin/perfmon_tables.php");
?>
