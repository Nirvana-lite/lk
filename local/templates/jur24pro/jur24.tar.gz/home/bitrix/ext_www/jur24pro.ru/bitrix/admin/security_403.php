<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/security/admin/security_403.php");
?>
