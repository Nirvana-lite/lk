<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/form/admin/form_field_edit_simple.php");?>
