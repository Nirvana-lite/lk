<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/bitrixcloud/admin/bitrixcloud_backup_job.php");
?>