<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/admin/culture_edit.php");
?>