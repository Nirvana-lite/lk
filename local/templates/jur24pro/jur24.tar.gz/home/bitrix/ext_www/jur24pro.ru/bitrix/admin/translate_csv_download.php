<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/translate/admin/translate_csv_download.php");