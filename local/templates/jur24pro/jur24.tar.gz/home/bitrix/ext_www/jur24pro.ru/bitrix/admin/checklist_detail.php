<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/admin/checklist_detail.php");
?>
