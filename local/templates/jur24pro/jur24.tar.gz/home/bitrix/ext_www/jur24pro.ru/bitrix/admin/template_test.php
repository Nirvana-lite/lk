<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/subscribe/admin/template_test.php");
?>
